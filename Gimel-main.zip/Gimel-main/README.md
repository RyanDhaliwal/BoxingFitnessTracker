# cmpe_template
Repository Template for cmpe course work, single repo with folders for individual assignments, labs, and demos.
