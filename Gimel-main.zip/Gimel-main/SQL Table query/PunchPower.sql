DROP TABLE PunchPower
CREATE TABLE PunchPower(
	UserName varchar(20) /*PRIMARY KEY*/,
	ppower  INT,
	speed FLOAT,
	RecievedTime varchar(30)
	)