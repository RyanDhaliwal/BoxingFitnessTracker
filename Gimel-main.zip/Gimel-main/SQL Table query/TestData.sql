DROP TABLE TestData
CREATE TABLE TestData(
	accelx  varchar(10),
	accely varchar(10),
	accelz varchar(10),
	gyrox varchar(10),
	gyroy varchar(10),
	gyroz varchar(10),
	pcount varchar(10),
	RecievedTime varchar(30)
	)